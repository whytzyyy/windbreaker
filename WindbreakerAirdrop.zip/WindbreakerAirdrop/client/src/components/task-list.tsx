import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Task, User } from "@shared/schema";
import { CheckCircle, Twitter, MessageCircle, Send, Repeat } from "lucide-react";

interface TaskListProps {
  tasks: Task[];
  user: User;
}

const taskIcons = {
  twitter: Twitter,
  discord: MessageCircle,
  telegram: Send,
  repost: Repeat,
};

const taskColors = {
  twitter: "bg-blue-500 hover:bg-blue-600",
  discord: "bg-indigo-500 hover:bg-indigo-600", 
  telegram: "bg-cyan-500 hover:bg-cyan-600",
  repost: "bg-emerald-500 hover:bg-emerald-600",
};

const taskNames = {
  twitter: "Follow @WindbreakerToken",
  discord: "Join Discord Server",
  telegram: "Join Telegram Group",
  repost: "Repost Our Tweet",
};

const taskDescriptions = {
  twitter: "Follow us on Twitter",
  discord: "Connect with our community",
  telegram: "Get latest updates", 
  repost: "Help spread the word",
};

export default function TaskList({ tasks, user }: TaskListProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const completeTaskMutation = useMutation({
    mutationFn: async (taskType: string) => {
      const response = await apiRequest("POST", "/api/complete-task", {
        userId: user.id,
        taskType,
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Task Completed!",
        description: data.message,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user", user.walletAddress] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleTaskComplete = (taskType: string) => {
    completeTaskMutation.mutate(taskType);
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardContent className="p-6">
        <h3 className="text-xl font-bold mb-6 flex items-center">
          <CheckCircle className="w-5 h-5 mr-2 text-primary" />
          Complete Tasks
          <span className="ml-2 text-sm font-normal text-slate-400">(+50 $WB each)</span>
        </h3>
        
        <div className="space-y-4">
          {tasks.map((task) => {
            const Icon = taskIcons[task.taskType as keyof typeof taskIcons];
            const colorClass = taskColors[task.taskType as keyof typeof taskColors];
            const taskName = taskNames[task.taskType as keyof typeof taskNames];
            const taskDescription = taskDescriptions[task.taskType as keyof typeof taskDescriptions];

            return (
              <div key={task.id} className="flex items-center justify-between p-4 bg-slate-700/50 rounded-lg border border-slate-600">
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 ${colorClass.split(' ')[0]} rounded-full flex items-center justify-center`}>
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h4 className="font-medium">{taskName}</h4>
                    <p className="text-sm text-slate-400">{taskDescription}</p>
                  </div>
                </div>
                {task.completed ? (
                  <div className="flex items-center space-x-2">
                    <span className="bg-emerald-500/20 text-emerald-400 px-2 py-1 rounded text-xs">
                      <CheckCircle className="w-3 h-3 inline mr-1" />
                      Completed
                    </span>
                  </div>
                ) : (
                  <Button
                    onClick={() => handleTaskComplete(task.taskType)}
                    className={`${colorClass} text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors`}
                    disabled={completeTaskMutation.isPending}
                  >
                    Complete
                  </Button>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
