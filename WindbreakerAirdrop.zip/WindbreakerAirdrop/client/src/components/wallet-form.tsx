import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Wind, Wallet, Gift, UserPlus } from "lucide-react";
import logoPath from "@assets/Picsart_25-07-22_01-20-34-629_1753122225659.png";

interface WalletFormProps {
  onSuccess: (walletAddress: string) => void;
}

export default function WalletForm({ onSuccess }: WalletFormProps) {
  const [walletAddress, setWalletAddress] = useState("");
  const { toast } = useToast();
  
  // Check for referral parameter
  const urlParams = new URLSearchParams(window.location.search);
  const referrer = urlParams.get('ref');

  const submitWalletMutation = useMutation({
    mutationFn: async (data: { walletAddress: string; referrer?: string }) => {
      const response = await apiRequest("POST", "/api/submit-wallet", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Success!",
        description: data.message,
      });
      onSuccess(walletAddress);
    },
    onError: (error: any) => {
      // If wallet already exists, redirect to dashboard anyway
      if (error.message === "Wallet already submitted") {
        toast({
          title: "Welcome back!",
          description: "Redirecting to your dashboard...",
        });
        onSuccess(walletAddress);
      } else {
        toast({
          title: "Error",
          description: error.message,
          variant: "destructive",
        });
      }
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!walletAddress || walletAddress.length < 32) {
      toast({
        title: "Invalid Address",
        description: "Please enter a valid Solana wallet address",
        variant: "destructive",
      });
      return;
    }

    submitWalletMutation.mutate({ walletAddress, referrer: referrer || undefined });
  };

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="text-center space-y-6">
        <div className="relative bg-gradient-to-r from-slate-800 to-slate-700 rounded-3xl p-8 overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-4 left-4 w-20 h-20 border border-cyan-400 rounded-full animate-pulse"></div>
            <div className="absolute bottom-4 right-4 w-16 h-16 border border-blue-400 rounded-full animate-pulse" style={{animationDelay: '1s'}}></div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 border border-cyan-400/30 rounded-full animate-pulse" style={{animationDelay: '2s'}}></div>
          </div>
          
          <div className="relative z-10">
            <div className="inline-flex items-center bg-gradient-to-r from-cyan-500 to-blue-500 text-white px-4 py-2 rounded-full text-sm font-medium mb-4">
              <Gift className="w-4 h-4 mr-2" />
              Free Airdrop Available
            </div>
            
            <h2 className="text-4xl md:text-6xl font-bold mb-4">
              Claim Your <span className="bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">Tokens</span>
            </h2>
            
            <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
              Join the Windbreaker community and get rewarded! Submit your Solana wallet address to claim your free tokens.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-8">
              <div className="bg-slate-700/50 p-6 rounded-xl border border-slate-600">
                <div className="text-3xl font-bold text-cyan-400">500</div>
                <div className="text-slate-300">Base Reward</div>
                <div className="text-sm text-slate-400">Tokens</div>
              </div>
              <div className="bg-slate-700/50 p-6 rounded-xl border border-slate-600">
                <div className="text-3xl font-bold text-blue-400">700</div>
                <div className="text-slate-300">With Referral</div>
                <div className="text-sm text-slate-400">Tokens</div>
              </div>
              <div className="bg-slate-700/50 p-6 rounded-xl border border-slate-600">
                <div className="text-3xl font-bold text-cyan-500">50</div>
                <div className="text-slate-300">Daily Mining</div>
                <div className="text-sm text-slate-400">Tokens</div>
              </div>
            </div>
          </div>
        </div>

        {/* Wallet Submission Form */}
        <Card className="bg-slate-800 border-slate-700 max-w-2xl mx-auto">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold mb-6">Submit Your Solana Wallet</h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="wallet-address" className="block text-sm font-medium text-slate-300 mb-2">
                  Solana Wallet Address
                </label>
                <div className="relative">
                  <Input
                    type="text"
                    id="wallet-address"
                    placeholder="Enter your Solana wallet address (e.g., 7xKX...)"
                    className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 pr-10"
                    value={walletAddress}
                    onChange={(e) => setWalletAddress(e.target.value)}
                    required
                  />
                  <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                    <Wallet className="w-4 h-4 text-slate-400" />
                  </div>
                </div>
                <p className="text-xs text-slate-400 mt-2">
                  No wallet connection required - just paste your address
                </p>
              </div>

              {referrer && (
                <div className="bg-gradient-to-r from-emerald-500/10 to-accent/10 border border-emerald-500/20 rounded-lg p-4">
                  <div className="flex items-center space-x-2 text-emerald-400">
                    <UserPlus className="w-4 h-4" />
                    <span className="font-medium">Referral Bonus Active!</span>
                  </div>
                  <p className="text-sm text-slate-300 mt-1">
                    You'll receive <strong>700 $WB</strong> instead of 500 $WB
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    Referred by: {referrer}
                  </p>
                </div>
              )}

              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-primary to-accent hover:from-primary/80 hover:to-accent/80 text-white font-bold py-4 px-6 rounded-lg transition-all duration-200 transform hover:scale-[1.02]"
                disabled={submitWalletMutation.isPending}
              >
                <Wind className="w-4 h-4 mr-2" />
                {submitWalletMutation.isPending ? "Submitting..." : "Claim My $WB Tokens"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
