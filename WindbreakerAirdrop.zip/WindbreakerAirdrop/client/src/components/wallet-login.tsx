import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Wallet } from "lucide-react";

interface WalletLoginProps {
  onSuccess: (walletAddress: string) => void;
}

export default function WalletLogin({ onSuccess }: WalletLoginProps) {
  const [walletAddress, setWalletAddress] = useState("");
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!walletAddress || walletAddress.length < 32) {
      toast({
        title: "Invalid Address",
        description: "Please enter a valid Solana wallet address",
        variant: "destructive",
      });
      return;
    }

    // Simply redirect to dashboard for existing wallets
    onSuccess(walletAddress);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="login-wallet" className="block text-sm font-medium text-slate-300 mb-2">
          Your Wallet Address
        </label>
        <div className="relative">
          <Input
            type="text"
            id="login-wallet"
            placeholder="Enter your Solana wallet address..."
            className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 pr-10"
            value={walletAddress}
            onChange={(e) => setWalletAddress(e.target.value)}
            required
          />
          <div className="absolute inset-y-0 right-0 flex items-center pr-3">
            <Wallet className="w-4 h-4 text-slate-400" />
          </div>
        </div>
      </div>

      <Button 
        type="submit" 
        className="w-full bg-primary hover:bg-primary/80 text-white font-medium py-2 px-4 rounded-lg transition-colors"
      >
        Access Dashboard
      </Button>
    </form>
  );
}