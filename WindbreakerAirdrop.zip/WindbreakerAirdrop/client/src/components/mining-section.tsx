import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";
import { Pickaxe, Gem } from "lucide-react";

interface MiningSectionProps {
  user: User;
  canClaimMining: boolean;
}

export default function MiningSection({ user, canClaimMining }: MiningSectionProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [timeRemaining, setTimeRemaining] = useState("");
  const [progressPercentage, setProgressPercentage] = useState(0);

  const claimMiningMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/claim-mining", {
        userId: user.id,
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Mining Reward Claimed!",
        description: data.message,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user", user.walletAddress] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!canClaimMining && user.lastClaimedMining) {
      const interval = setInterval(() => {
        const now = new Date();
        const lastClaim = new Date(user.lastClaimedMining!);
        const nextClaim = new Date(lastClaim.getTime() + 24 * 60 * 60 * 1000);
        const timeDiff = nextClaim.getTime() - now.getTime();

        if (timeDiff <= 0) {
          setTimeRemaining("00h 00m 00s");
          setProgressPercentage(100);
          queryClient.invalidateQueries({ queryKey: ["/api/user", user.walletAddress] });
          return;
        }

        const hours = Math.floor(timeDiff / (1000 * 60 * 60));
        const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeDiff % (1000 * 60)) / 1000);

        setTimeRemaining(`${hours.toString().padStart(2, '0')}h ${minutes.toString().padStart(2, '0')}m ${seconds.toString().padStart(2, '0')}s`);
        
        // Calculate progress (24 hours = 100%)
        const elapsed = 24 * 60 * 60 * 1000 - timeDiff;
        const percentage = (elapsed / (24 * 60 * 60 * 1000)) * 100;
        setProgressPercentage(Math.max(0, Math.min(100, percentage)));
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [canClaimMining, user.lastClaimedMining, user.walletAddress, queryClient]);

  const handleClaimMining = () => {
    claimMiningMutation.mutate();
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold flex items-center">
            <Pickaxe className="w-5 h-5 mr-2 text-accent" />
            Daily Mining
          </h3>
          <div className="text-emerald-400 font-bold">+50 $WB</div>
        </div>
        
        {canClaimMining ? (
          <div className="space-y-4">
            <p className="text-slate-300">Mine your daily $WB tokens!</p>
            <Button 
              onClick={handleClaimMining}
              className="w-full bg-gradient-to-r from-accent to-accent/80 hover:from-accent/80 hover:to-accent/60 text-white font-bold py-3 px-4 rounded-lg transition-colors"
              disabled={claimMiningMutation.isPending}
            >
              <Gem className="w-4 h-4 mr-2" />
              {claimMiningMutation.isPending ? "Claiming..." : "Claim Daily Reward"}
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-slate-300">Come back tomorrow for your next reward!</p>
            <div className="bg-slate-700 p-4 rounded-lg">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400">Next claim in:</span>
                <span className="font-mono text-accent">{timeRemaining}</span>
              </div>
              <Progress 
                value={progressPercentage} 
                className="w-full mt-2 h-2 bg-slate-600"
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
