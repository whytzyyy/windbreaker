import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";
import { Users, Copy, Info } from "lucide-react";

interface ReferralSectionProps {
  user: User;
  referralCount: number;
}

export default function ReferralSection({ user, referralCount }: ReferralSectionProps) {
  const { toast } = useToast();
  
  const referralLink = `${window.location.origin}?ref=${user.walletAddress}`;
  
  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink);
    toast({
      title: "Copied!",
      description: "Referral link copied to clipboard!",
    });
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardContent className="p-6">
        <h3 className="text-xl font-bold mb-4 flex items-center">
          <Users className="w-5 h-5 mr-2 text-emerald-400" />
          Referrals
        </h3>
        
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-emerald-500/10 to-emerald-600/10 border border-emerald-500/20 rounded-lg p-4">
            <div className="text-2xl font-bold text-emerald-400">{referralCount}</div>
            <div className="text-sm text-slate-300">Total Referrals</div>
            <div className="text-xs text-slate-400">+{referralCount * 100} $WB earned</div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Your Referral Link</label>
            <div className="flex">
              <Input 
                type="text" 
                readOnly 
                value={referralLink}
                className="flex-1 bg-slate-700 border-slate-600 text-sm text-slate-300 rounded-r-none focus:outline-none"
              />
              <Button 
                onClick={copyReferralLink}
                className="bg-primary hover:bg-primary/80 px-4 py-2 rounded-l-none text-white transition-colors"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="text-sm text-slate-400 bg-slate-700/50 p-3 rounded-lg">
            <Info className="w-4 h-4 inline mr-2" />
            Share your link to earn 100 $WB per referral!
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
