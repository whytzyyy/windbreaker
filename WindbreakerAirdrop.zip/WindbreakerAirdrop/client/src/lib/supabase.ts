// This file is kept for reference, but we're using Drizzle directly as per blueprint guidelines
export const SUPABASE_URL = "https://mlolzpivvdstdgokricy.supabase.co";
export const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1sb2x6cGl2dmRzdGRnb2tyaWN5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMxMDI2ODcsImV4cCI6MjA2ODY3ODY4N30.TDL8lEh5EM-PbRp5qAEaONE6dVVB5iV6DLHR5kTAbik";
