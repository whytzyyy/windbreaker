import { useState } from "react";
import WalletForm from "@/components/wallet-form";
import WalletLogin from "@/components/wallet-login";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { LogIn } from "lucide-react";
import logoPath from "@assets/Picsart_25-07-22_01-20-34-629_1753122225659.png";

export default function Home() {
  const [, navigate] = useLocation();
  const [showLoginForm, setShowLoginForm] = useState(false);

  const handleWalletSuccess = (walletAddress: string) => {
    console.log('Navigating to dashboard with wallet:', walletAddress);
    const encodedWallet = encodeURIComponent(walletAddress);
    const targetUrl = `/dashboard?wallet=${encodedWallet}`;
    console.log('Target URL:', targetUrl);
    navigate(targetUrl);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center">
                <img src={logoPath} alt="Windbreaker Logo" className="w-10 h-10 object-contain" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Windbreaker</h1>
                <p className="text-xs text-slate-400">Solana Airdrop</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="hidden md:block">
                <div className="bg-slate-700 px-3 py-1 rounded-full text-sm">
                  <span className="text-emerald-400">●</span> Live on Pump.fun
                </div>
              </div>
              <Button
                onClick={() => setShowLoginForm(!showLoginForm)}
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                <LogIn className="w-4 h-4 mr-2" />
                {showLoginForm ? "Hide Login" : "Already Have Wallet?"}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {showLoginForm ? (
          <div className="max-w-md mx-auto">
            <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4">Access Your Dashboard</h3>
              <p className="text-slate-300 text-sm mb-4">
                Enter your wallet address to access your dashboard and claim rewards.
              </p>
              <WalletLogin onSuccess={handleWalletSuccess} />
            </div>
          </div>
        ) : (
          <WalletForm onSuccess={handleWalletSuccess} />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 border-t border-slate-700 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 rounded-full flex items-center justify-center">
                  <img src={logoPath} alt="Windbreaker Logo" className="w-8 h-8 object-contain" />
                </div>
                <span className="text-lg font-bold">Windbreaker</span>
              </div>
              <p className="text-slate-400 text-sm">
                Join the Windbreaker revolution on Solana. Earn rewards, complete tasks, and be part of our growing community.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Community</h4>
              <div className="space-y-2">
                <a href="#" className="flex items-center text-slate-400 hover:text-white transition-colors">
                  <i className="fab fa-twitter mr-2"></i>
                  Twitter
                </a>
                <a href="#" className="flex items-center text-slate-400 hover:text-white transition-colors">
                  <i className="fab fa-discord mr-2"></i>
                  Discord
                </a>
                <a href="#" className="flex items-center text-slate-400 hover:text-white transition-colors">
                  <i className="fab fa-telegram mr-2"></i>
                  Telegram
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <div className="space-y-2">
                <a href="#" className="flex items-center text-slate-400 hover:text-white transition-colors">
                  <i className="fas fa-external-link-alt mr-2"></i>
                  Pump.fun Page
                </a>
                <a href="#" className="flex items-center text-slate-400 hover:text-white transition-colors">
                  <i className="fas fa-file-alt mr-2"></i>
                  Whitepaper
                </a>
                <a href="#" className="flex items-center text-slate-400 hover:text-white transition-colors">
                  <i className="fas fa-chart-line mr-2"></i>
                  Token Analytics
                </a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-slate-700 mt-8 pt-8 text-center">
            <p className="text-slate-400 text-sm">
              © 2024 Windbreaker Token. Built on Solana. Powered by community.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
