import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import TaskList from "@/components/task-list";
import MiningSection from "@/components/mining-section";
import ReferralSection from "@/components/referral-section";
import { useLocation } from "wouter";
import { ExternalLink, History, Gift, CheckCircle, Pickaxe, Info } from "lucide-react";
import logoPath from "@assets/Picsart_25-07-22_01-20-34-629_1753122225659.png";

export default function Dashboard() {
  const [location] = useLocation();
  
  // Parse wallet address from URL
  const urlParams = new URLSearchParams(window.location.search);
  const walletAddress = urlParams.get('wallet');
  
  // Debug logging
  console.log('Dashboard location:', location);
  console.log('URL search:', window.location.search);
  console.log('Wallet address:', walletAddress);

  if (!walletAddress) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Access Denied</h2>
            <p className="text-slate-300">Please submit your wallet address first.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/user", walletAddress],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-xl">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    console.error('Dashboard error:', error);
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-8 text-center space-y-4">
            <h2 className="text-2xl font-bold mb-4">Error</h2>
            <p className="text-slate-300">Failed to load user data. Please try again.</p>
            <Button 
              onClick={() => window.location.reload()} 
              className="bg-primary hover:bg-primary/80"
            >
              Refresh Page
            </Button>
            <p className="text-xs text-slate-400">
              Wallet: {walletAddress}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { user, tasks, referralCount, canClaimMining } = data as {
    user: any;
    tasks: any[];
    referralCount: number;
    canClaimMining: boolean;
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center">
                <img src={logoPath} alt="Windbreaker Logo" className="w-10 h-10 object-contain" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Windbreaker</h1>
                <p className="text-xs text-slate-400">Solana Airdrop</p>
              </div>
            </div>
            <div className="hidden md:block">
              <div className="bg-slate-700 px-3 py-1 rounded-full text-sm">
                <span className="text-emerald-400">●</span> Live on Pump.fun
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Dashboard Header */}
        <div className="bg-gradient-to-r from-slate-800 to-slate-700 p-6 rounded-2xl border border-slate-600">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-2xl font-bold mb-2">Welcome back!</h2>
              <p className="text-slate-300">
                Wallet: {user.walletAddress.slice(0, 4)}...{user.walletAddress.slice(-4)}
              </p>
            </div>
            <div className="mt-4 md:mt-0">
              <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 px-6 py-3 rounded-xl">
                <div className="text-emerald-100 text-sm">Total Balance</div>
                <div className="text-2xl font-bold text-white">{user.balance.toLocaleString()} $WB</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <MiningSection user={user} canClaimMining={canClaimMining} />
            <TaskList tasks={tasks} user={user} />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <ReferralSection user={user} referralCount={referralCount} />

            {/* Recent Activity */}
            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4 flex items-center">
                  <History className="w-5 h-5 mr-2 text-slate-400" />
                  Recent Activity
                </h3>
                
                <div className="space-y-3">
                  {referralCount > 0 && (
                    <div className="flex items-center justify-between py-2 border-b border-slate-700">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center">
                          <Gift className="w-3 h-3 text-white" />
                        </div>
                        <div>
                          <div className="text-sm font-medium">Referral Bonus</div>
                          <div className="text-xs text-slate-400">Recent</div>
                        </div>
                      </div>
                      <div className="text-emerald-400 font-bold text-sm">+{referralCount * 100} $WB</div>
                    </div>
                  )}

                  {!canClaimMining && (
                    <div className="flex items-center justify-between py-2 border-b border-slate-700">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                          <Pickaxe className="w-3 h-3 text-white" />
                        </div>
                        <div>
                          <div className="text-sm font-medium">Daily Mining</div>
                          <div className="text-xs text-slate-400">Last claimed</div>
                        </div>
                      </div>
                      <div className="text-accent font-bold text-sm">+50 $WB</div>
                    </div>
                  )}

                  {tasks.filter((t: any) => t.completed).length > 0 && (
                    <div className="flex items-center justify-between py-2">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                          <CheckCircle className="w-3 h-3 text-white" />
                        </div>
                        <div>
                          <div className="text-sm font-medium">Tasks Completed</div>
                          <div className="text-xs text-slate-400">{tasks.filter((t: any) => t.completed).length} tasks</div>
                        </div>
                      </div>
                      <div className="text-primary font-bold text-sm">+{tasks.filter((t: any) => t.completed).length * 50} $WB</div>
                    </div>
                  )}

                  {referralCount === 0 && canClaimMining && tasks.filter((t: any) => t.completed).length === 0 && (
                    <div className="text-center py-4 text-slate-400">
                      <p className="text-sm">No recent activity</p>
                      <p className="text-xs mt-1">Complete tasks to see activity here</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Token Info */}
            <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20">
              <CardContent className="p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center">
                  <Info className="w-5 h-5 mr-2 text-primary" />
                  About $WB Token
                </h3>
                
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Network:</span>
                    <span className="text-white">Solana</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Platform:</span>
                    <span className="text-white">Pump.fun</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Symbol:</span>
                    <span className="text-white">$WB</span>
                  </div>
                  
                  <div className="pt-3 border-t border-slate-700">
                    <a href="#" className="inline-flex items-center text-primary hover:text-primary/80 transition-colors">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      View on Pump.fun
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
