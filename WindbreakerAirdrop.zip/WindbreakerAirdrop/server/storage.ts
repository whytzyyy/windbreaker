import { users, referrals, tasks, miningLogs, type User, type InsertUser, type Referral, type InsertReferral, type Task, type InsertTask, type MiningLog, type InsertMiningLog } from "@shared/schema";
import { drizzle } from "drizzle-orm/neon-serverless";
import { Pool } from "@neondatabase/serverless";
import { eq, and } from "drizzle-orm";

const pool = new Pool({ 
  connectionString: process.env.DATABASE_URL || "postgresql://postgres:password@localhost:5432/windbreaker"
});
const db = drizzle(pool);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByWallet(walletAddress: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(id: number, balance: number): Promise<void>;
  updateUserMiningTime(id: number, lastClaimedMining: Date): Promise<void>;

  // Referral operations
  createReferral(referral: InsertReferral): Promise<Referral>;
  getReferralsByUser(userId: number): Promise<Referral[]>;
  getReferralCount(userId: number): Promise<number>;

  // Task operations
  getUserTasks(userId: number): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  completeTask(userId: number, taskType: string): Promise<void>;
  isTaskCompleted(userId: number, taskType: string): Promise<boolean>;

  // Mining operations
  createMiningLog(log: InsertMiningLog): Promise<MiningLog>;
  canClaimMining(userId: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private referrals: Map<number, Referral>;
  private tasks: Map<number, Task>;
  private miningLogs: Map<number, MiningLog>;
  private currentUserId: number;
  private currentReferralId: number;
  private currentTaskId: number;
  private currentMiningId: number;

  constructor() {
    this.users = new Map();
    this.referrals = new Map();
    this.tasks = new Map();
    this.miningLogs = new Map();
    this.currentUserId = 1;
    this.currentReferralId = 1;
    this.currentTaskId = 1;
    this.currentMiningId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByWallet(walletAddress: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.walletAddress === walletAddress);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = {
      ...insertUser,
      id,
      balance: insertUser.balance ?? 0,
      lastClaimedMining: insertUser.lastClaimedMining ?? null,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserBalance(id: number, balance: number): Promise<void> {
    const user = this.users.get(id);
    if (user) {
      user.balance = balance;
      this.users.set(id, user);
    }
  }

  async updateUserMiningTime(id: number, lastClaimedMining: Date): Promise<void> {
    const user = this.users.get(id);
    if (user) {
      user.lastClaimedMining = lastClaimedMining;
      this.users.set(id, user);
    }
  }

  async createReferral(insertReferral: InsertReferral): Promise<Referral> {
    const id = this.currentReferralId++;
    const referral: Referral = {
      ...insertReferral,
      id,
      bonusAwarded: insertReferral.bonusAwarded ?? false,
      createdAt: new Date(),
    };
    this.referrals.set(id, referral);
    return referral;
  }

  async getReferralsByUser(userId: number): Promise<Referral[]> {
    return Array.from(this.referrals.values()).filter(referral => referral.referrerId === userId);
  }

  async getReferralCount(userId: number): Promise<number> {
    return Array.from(this.referrals.values()).filter(referral => referral.referrerId === userId).length;
  }

  async getUserTasks(userId: number): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(task => task.userId === userId);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.currentTaskId++;
    const task: Task = {
      ...insertTask,
      id,
      completed: insertTask.completed ?? false,
      createdAt: new Date(),
      completedAt: null,
    };
    this.tasks.set(id, task);
    return task;
  }

  async completeTask(userId: number, taskType: string): Promise<void> {
    const task = Array.from(this.tasks.values()).find(
      t => t.userId === userId && t.taskType === taskType
    );
    if (task) {
      task.completed = true;
      task.completedAt = new Date();
      this.tasks.set(task.id, task);
    }
  }

  async isTaskCompleted(userId: number, taskType: string): Promise<boolean> {
    const task = Array.from(this.tasks.values()).find(
      t => t.userId === userId && t.taskType === taskType
    );
    return task?.completed || false;
  }

  async createMiningLog(insertLog: InsertMiningLog): Promise<MiningLog> {
    const id = this.currentMiningId++;
    const log: MiningLog = {
      ...insertLog,
      id,
      amount: insertLog.amount ?? 50,
      claimedAt: new Date(),
    };
    this.miningLogs.set(id, log);
    return log;
  }

  async canClaimMining(userId: number): Promise<boolean> {
    const user = await this.getUser(userId);
    if (!user || !user.lastClaimedMining) return true;
    
    const now = new Date();
    const lastClaim = new Date(user.lastClaimedMining);
    const timeDiff = now.getTime() - lastClaim.getTime();
    const hoursDiff = timeDiff / (1000 * 60 * 60);
    
    return hoursDiff >= 24;
  }
}

export class PostgresStorage implements IStorage {
  private db = drizzle(pool);

  async getUser(id: number): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByWallet(walletAddress: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.walletAddress, walletAddress)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await this.db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async updateUserBalance(id: number, balance: number): Promise<void> {
    await this.db.update(users).set({ balance }).where(eq(users.id, id));
  }

  async updateUserMiningTime(id: number, lastClaimedMining: Date): Promise<void> {
    await this.db.update(users).set({ lastClaimedMining }).where(eq(users.id, id));
  }

  async createReferral(insertReferral: InsertReferral): Promise<Referral> {
    const result = await this.db.insert(referrals).values(insertReferral).returning();
    return result[0];
  }

  async getReferralsByUser(userId: number): Promise<Referral[]> {
    return await this.db.select().from(referrals).where(eq(referrals.referrerId, userId));
  }

  async getReferralCount(userId: number): Promise<number> {
    const result = await this.db.select().from(referrals).where(eq(referrals.referrerId, userId));
    return result.length;
  }

  async getUserTasks(userId: number): Promise<Task[]> {
    return await this.db.select().from(tasks).where(eq(tasks.userId, userId));
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const result = await this.db.insert(tasks).values(insertTask).returning();
    return result[0];
  }

  async completeTask(userId: number, taskType: string): Promise<void> {
    await this.db.update(tasks)
      .set({ completed: true, completedAt: new Date() })
      .where(and(eq(tasks.userId, userId), eq(tasks.taskType, taskType)));
  }

  async isTaskCompleted(userId: number, taskType: string): Promise<boolean> {
    const result = await this.db.select()
      .from(tasks)
      .where(and(eq(tasks.userId, userId), eq(tasks.taskType, taskType)))
      .limit(1);
    return result[0]?.completed || false;
  }

  async createMiningLog(insertLog: InsertMiningLog): Promise<MiningLog> {
    const result = await this.db.insert(miningLogs).values(insertLog).returning();
    return result[0];
  }

  async canClaimMining(userId: number): Promise<boolean> {
    const user = await this.getUser(userId);
    if (!user || !user.lastClaimedMining) return true;
    
    const now = new Date();
    const lastClaim = new Date(user.lastClaimedMining);
    const timeDiff = now.getTime() - lastClaim.getTime();
    const hoursDiff = timeDiff / (1000 * 60 * 60);
    
    return hoursDiff >= 24;
  }
}

// Use PostgresStorage when DATABASE_URL is properly configured, fallback to MemStorage for demo
export const storage = process.env.DATABASE_URL && process.env.DATABASE_URL.startsWith('postgresql://') 
  ? new PostgresStorage() 
  : new MemStorage();
