import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertTaskSchema } from "@shared/schema";
import { z } from "zod";

const walletSubmitSchema = z.object({
  walletAddress: z.string().min(32, "Invalid Solana wallet address"),
  referrer: z.string().optional(),
});

const taskCompleteSchema = z.object({
  userId: z.number(),
  taskType: z.enum(["twitter", "discord", "telegram", "repost"]),
});

const miningClaimSchema = z.object({
  userId: z.number(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Submit wallet address
  app.post("/api/submit-wallet", async (req, res) => {
    try {
      const { walletAddress, referrer } = walletSubmitSchema.parse(req.body);
      
      // Check if wallet already exists
      const existingUser = await storage.getUserByWallet(walletAddress);
      if (existingUser) {
        return res.status(400).json({ message: "Wallet already submitted" });
      }

      // Determine initial balance
      let initialBalance = 500;
      let referrerUser = null;
      
      if (referrer) {
        referrerUser = await storage.getUserByWallet(referrer);
        if (referrerUser) {
          initialBalance = 700; // Bonus for referred user
        }
      }

      // Create new user
      const newUser = await storage.createUser({
        walletAddress,
        balance: initialBalance,
        lastClaimedMining: null,
      });

      // Handle referral bonus
      if (referrerUser) {
        await storage.createReferral({
          referrerId: referrerUser.id,
          referredId: newUser.id,
          bonusAwarded: false,
        });

        // Award referrer bonus
        await storage.updateUserBalance(referrerUser.id, referrerUser.balance + 100);
      }

      // Initialize tasks for the new user
      const taskTypes = ["twitter", "discord", "telegram", "repost"];
      for (const taskType of taskTypes) {
        await storage.createTask({
          userId: newUser.id,
          taskType,
          completed: false,
        });
      }

      res.json({ 
        user: newUser,
        message: `Welcome! You've received ${initialBalance} $WB tokens.`
      });
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Invalid request" });
    }
  });

  // Get user data or create if not exists
  app.get("/api/user/:walletAddress", async (req, res) => {
    try {
      const { walletAddress } = req.params;
      let user = await storage.getUserByWallet(walletAddress);
      
      // If user doesn't exist, create them with default values
      if (!user) {
        user = await storage.createUser({
          walletAddress,
          balance: 500,
          lastClaimedMining: null,
        });

        // Initialize tasks for the new user
        const taskTypes = ["twitter", "discord", "telegram", "repost"];
        for (const taskType of taskTypes) {
          await storage.createTask({
            userId: user.id,
            taskType,
            completed: false,
          });
        }
      }

      const tasks = await storage.getUserTasks(user.id);
      const referralCount = await storage.getReferralCount(user.id);
      const canClaimMining = await storage.canClaimMining(user.id);

      res.json({
        user,
        tasks,
        referralCount,
        canClaimMining,
      });
    } catch (error) {
      console.error("Error in /api/user:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // Complete task
  app.post("/api/complete-task", async (req, res) => {
    try {
      const { userId, taskType } = taskCompleteSchema.parse(req.body);
      
      // Check if task already completed
      const isCompleted = await storage.isTaskCompleted(userId, taskType);
      if (isCompleted) {
        return res.status(400).json({ message: "Task already completed" });
      }

      // Complete the task
      await storage.completeTask(userId, taskType);

      // Award task completion bonus
      const user = await storage.getUser(userId);
      if (user) {
        await storage.updateUserBalance(userId, user.balance + 50);
      }

      res.json({ message: "Task completed! +50 $WB earned" });
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Invalid request" });
    }
  });

  // Claim daily mining
  app.post("/api/claim-mining", async (req, res) => {
    try {
      const { userId } = miningClaimSchema.parse(req.body);
      
      // Check if user can claim
      const canClaim = await storage.canClaimMining(userId);
      if (!canClaim) {
        return res.status(400).json({ message: "Mining reward not available yet" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Update user balance and mining time
      await storage.updateUserBalance(userId, user.balance + 50);
      await storage.updateUserMiningTime(userId, new Date());

      // Log mining activity
      await storage.createMiningLog({
        userId,
        amount: 50,
      });

      res.json({ message: "Daily mining reward claimed! +50 $WB" });
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Invalid request" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
